<?php 
   $destination=" alian_zalima@hotmail.com"
   $name= $_POST["Name"];
   $mail= $_POST["Mail"];
$message= $_POST["Message"];   
$content = "Name" . $Name "\nMail " . $Mail . "\nMessage" . $Message;
mail($destination, "Contact", $content);
header("Location:thanks.html");
?>